import { randomUUID } from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { DirectError, directId, ReadRateLimitError } from './direct-api.ts';
import { hash } from './campaign-plan.ts';
import type { openDatabase } from './database.ts';
import type { DirectConnection } from './direct.ts';
import type { MetrikaCounter, MetrikaProvider, MetrikaQuery } from './metrika-api.ts';

export type AnalyticsSource='direct_reports'|'metrika_site'|'metrika_direct';
export type AnalyticsSettings={revision:number;generation:number;metrikaEnabled:boolean;metrikaConfigId?:string;directRunId?:string;counter?:MetrikaCounter;goalId?:string;dateFrom:string;dateTo:string};
export type AnalyticsReport={id:string;source:AnalyticsSource;status:'pending'|'ready'|'empty'|'error'|'superseded';requestedAt:string;receivedAt?:string;settingsRevision:number;connectionGeneration?:number;configId?:string;mode:'fixture'|'live';requestKey:string;
  context:{dateFrom:string;dateTo:string;timezone:string;attribution:string;currency:string;vat:string;runId?:string;planId?:string;planHash?:string;planTitle?:string;planConfirmedAt?:string;account?:string;campaignId?:string;counterId?:string;domain?:string;goalId?:string;goalName?:string;businessMeaning:'not_agreed'};
  query:any;result?:any;error?:string;retryAt?:number;cooldownUntil?:number;pid?:number;attempts:number;stale?:boolean;interrupted?:boolean;offlinePending?:boolean;failures?:{at?:string;message:string;retryAt?:number}[]};
export const analyticsDates=(now=Date.now())=>{const end=new Date(now-86400000+10800000).toISOString().slice(0,10);return{dateFrom:new Date(Date.parse(end)-6*86400000).toISOString().slice(0,10),dateTo:end};};
export function validateDates(from:string,to:string,now=Date.now()){
  const a=Date.parse(from),b=Date.parse(to);if(!/^\d{4}-\d{2}-\d{2}$/.test(from)||!/^\d{4}-\d{2}-\d{2}$/.test(to)||!Number.isFinite(a)||!Number.isFinite(b)||new Date(a).toISOString().slice(0,10)!==from||new Date(b).toISOString().slice(0,10)!==to||b<a||b-a>30*86400000||b+86400000-10800000>now)throw new DirectError('Выберите от 1 до 31 завершённого календарного дня МСК.');
}
export function sameSite(url:string,counter:MetrikaCounter){
  const hostname=(value:string)=>{try{return new URL(value.includes('://')?value:`https://${value}`).hostname.replace(/^www\./,'').toLowerCase();}catch{return '';}};
  const site=hostname(url);return Boolean(site&&[counter.domain,...counter.mirrors].some(s=>hostname(s)===site));
}
export function migrateAnalytics(db:DatabaseSync){
  db.exec(`CREATE TABLE analytics_settings(owner TEXT PRIMARY KEY,revision INTEGER NOT NULL,payload TEXT NOT NULL CHECK(json_valid(payload))) STRICT;
    CREATE TABLE analytics_reports(owner TEXT NOT NULL,id TEXT NOT NULL,source TEXT NOT NULL,request_key TEXT NOT NULL,status TEXT NOT NULL,payload TEXT NOT NULL CHECK(json_valid(payload)),PRIMARY KEY(owner,id)) STRICT;
    CREATE UNIQUE INDEX analytics_pending ON analytics_reports(owner,source) WHERE status='pending';
    CREATE TABLE demo_automation(owner TEXT PRIMARY KEY,revision INTEGER NOT NULL,enabled INTEGER NOT NULL CHECK(enabled IN(0,1)),plan_id TEXT NOT NULL,policy_version TEXT NOT NULL,payload TEXT NOT NULL CHECK(json_valid(payload))) STRICT;
    ALTER TABLE demo_jobs ADD COLUMN expected_revision INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE demo_jobs ADD COLUMN state_hash TEXT NOT NULL DEFAULT '';
    ALTER TABLE demo_jobs ADD COLUMN context_hash TEXT NOT NULL DEFAULT '';
    ALTER TABLE demo_jobs ADD COLUMN authorization_revision INTEGER NOT NULL DEFAULT 0;
    PRAGMA user_version=10;`);
}
export function createAnalyticsStore(db:DatabaseSync){
  function settings(owner:string):AnalyticsSettings{const r=db.prepare('SELECT revision,payload FROM analytics_settings WHERE owner=?').get(owner);return r?{...JSON.parse(String(r.payload)),revision:Number(r.revision)}:{revision:0,generation:0,metrikaEnabled:false,...analyticsDates()};}
  function decode(payload:string):AnalyticsReport{
    const value=JSON.parse(payload) as AnalyticsReport;const age=Date.now()-Date.parse(value.receivedAt??'');value.stale=Boolean(value.receivedAt&&(!Number.isFinite(age)||age<0||age>86400000));
    value.offlinePending=value.source==='direct_reports'&&Boolean(value.offlinePending||value.result?.status==='pending');
    if(value.status==='pending'&&value.source!=='direct_reports'&&value.pid){try{process.kill(value.pid,0);}catch(error){if((error as NodeJS.ErrnoException).code==='ESRCH')value.interrupted=true;}}
    return value;
  }
  function reports(owner:string):AnalyticsReport[]{return db.prepare('SELECT payload FROM analytics_reports WHERE owner=? ORDER BY rowid DESC LIMIT 30').all(owner).map(r=>decode(String(r.payload)));}
  return {readAnalyticsSettings:settings,readAnalyticsReports:reports,
    readAnalyticsCooldown(owner:string,source:AnalyticsSource):AnalyticsReport|undefined{
      const scope=source==='direct_reports'?"source='direct_reports'":"source IN('metrika_site','metrika_direct')";
      const row=db.prepare(`SELECT payload FROM analytics_reports WHERE owner=? AND ${scope} AND json_extract(payload,'$.cooldownUntil')>? ORDER BY json_extract(payload,'$.cooldownUntil') DESC LIMIT 1`).get(owner,Date.now());
      return row?decode(String(row.payload)):undefined;
    },
    recordAnalyticsCooldown(owner:string,report:AnalyticsReport){db.prepare("INSERT INTO analytics_reports(owner,id,source,request_key,status,payload) VALUES(?,?,?,?,'error',?)").run(owner,report.id,report.source,report.requestKey,JSON.stringify(report));},
    saveAnalyticsCooldown(owner:string,id:string,until:number){db.prepare("UPDATE analytics_reports SET payload=json_set(payload,'$.cooldownUntil',?,'$.retryAt',?) WHERE owner=? AND id=?").run(until,until,owner,id);},
    saveAnalyticsSettings(owner:string,next:AnalyticsSettings,expected:number){
      db.exec('BEGIN IMMEDIATE');try{if(settings(owner).revision!==expected)throw new DirectError('Настройки аналитики уже изменены. Обновите страницу; ваши отчёты сохранены.');
        for(const row of db.prepare("SELECT payload FROM analytics_reports WHERE owner=? AND (status='pending' OR (source='direct_reports' AND status='error' AND (json_extract(payload,'$.offlinePending')=1 OR json_extract(payload,'$.result.status')='pending')))").all(owner)){const r=JSON.parse(String(row.payload)) as AnalyticsReport;r.status='superseded';r.error='Настройки изменены; ответ относится к прежнему контексту.';db.prepare('UPDATE analytics_reports SET status=?,payload=? WHERE owner=? AND id=?').run(r.status,JSON.stringify(r),owner,r.id);}
        db.prepare('INSERT INTO analytics_settings(owner,revision,payload) VALUES(?,?,?) ON CONFLICT(owner) DO UPDATE SET revision=excluded.revision,payload=excluded.payload').run(owner,expected+1,JSON.stringify({...next,revision:expected+1}));db.exec('COMMIT');return settings(owner);
      }catch(error){db.exec('ROLLBACK');throw error;}
    },
    beginAnalyticsReport(owner:string,value:AnalyticsReport){
      db.exec('BEGIN IMMEDIATE');try{const row=db.prepare("SELECT payload FROM analytics_reports WHERE owner=? AND source=? AND (status='pending' OR (source='direct_reports' AND status='error' AND (json_extract(payload,'$.offlinePending')=1 OR json_extract(payload,'$.result.status')='pending'))) ORDER BY rowid DESC LIMIT 1").get(owner,value.source);
        if(row){const existing=decode(String(row.payload));if(existing.status==='error'){
          existing.failures??=existing.error?[{message:existing.error}]:[];
          existing.status='pending';existing.error=undefined;
          db.prepare("UPDATE analytics_reports SET status='pending',payload=? WHERE owner=? AND id=?").run(JSON.stringify(existing),owner,existing.id);
        }db.exec('COMMIT');return existing;}
        db.prepare('INSERT INTO analytics_reports(owner,id,source,request_key,status,payload) VALUES(?,?,?,?,?,?)').run(owner,value.id,value.source,value.requestKey,value.status,JSON.stringify(value));db.exec('COMMIT');return value;
      }catch(error){db.exec('ROLLBACK');throw error;}
    },
    updateAnalyticsReport(owner:string,value:AnalyticsReport){return db.prepare("UPDATE analytics_reports SET status=?,payload=? WHERE owner=? AND id=? AND status='pending'").run(value.status,JSON.stringify(value),owner,value.id).changes===1;},
  };
}
export function createAnalyticsService(db:ReturnType<typeof openDatabase>,resolveDirect:(owner:string)=>DirectConnection|undefined,metrika?:MetrikaProvider){
  const inFlight=new Set<string>();
  const configured=(owner:string)=>metrika?.owner===owner;
  function direct(owner:string,s:AnalyticsSettings){const connection=resolveDirect(owner),run=s.directRunId?db.readDirect(owner,s.directRunId):undefined;
    if(!connection||!run||run.account!==connection.account||connection.owner!==owner||!run.steps.campaign.id||run.steps.campaign.phase!=='confirmed')throw new DirectError('Выберите подтверждённый набор своего подключённого Директа.');
    return{connection,run,campaignId:directId(run.steps.campaign.id)};
  }
  function view(owner:string){const settings=db.readAnalyticsSettings(owner);return {settings,reports:db.readAnalyticsReports(owner),metrikaConfigured:configured(owner),metrikaMode:configured(owner)?metrika!.mode:undefined,runs:db.readDirectRuns(owner),plans:db.readPlans(owner)};}
  function save(owner:string,form:URLSearchParams){const current=db.readAnalyticsSettings(owner),one=(key:string)=>form.getAll(key).length===1?form.get(key)!:'';
    if(String(current.revision)!==one('revision'))throw new DirectError('Настройки аналитики изменены. Обновите страницу.');
    const dateFrom=one('dateFrom'),dateTo=one('dateTo');validateDates(dateFrom,dateTo);
    const runId=one('directRunId');if(runId&&!db.readDirect(owner,runId))throw new DirectError('Набор не найден у этого владельца.');
    const goalId=one('goalId');if(goalId&&!current.counter?.goals.some(g=>g.id===goalId))throw new DirectError('Выберите цель из прочитанного счётчика.');
    return db.saveAnalyticsSettings(owner,{...current,dateFrom,dateTo,directRunId:runId||undefined,goalId:goalId||undefined},current.revision);
  }
  async function counter(owner:string,counterId:string,expected:number){
    const current=db.readAnalyticsSettings(owner);if(!configured(owner)||current.revision!==expected)throw new DirectError('Доступ Метрики не настроен или выбор устарел.');
    const cooldown=db.readAnalyticsCooldown(owner,'metrika_site');if(cooldown)throw new ReadRateLimitError('Метрика',cooldown.cooldownUntil!);
    try{
      const metadata=await metrika!.api.counter(counterId,()=>{if(db.readAnalyticsSettings(owner).revision!==expected)throw new DirectError('Настройки изменились до отправки.');const wait=db.readAnalyticsCooldown(owner,'metrika_site');if(wait)throw new ReadRateLimitError('Метрика',wait.cooldownUntil!);});
      return db.saveAnalyticsSettings(owner,{...current,counter:metadata,goalId:undefined,metrikaEnabled:true,metrikaConfigId:metrika!.configId,generation:current.generation+1},expected);
    }catch(error){
      if(error instanceof ReadRateLimitError)db.recordAnalyticsCooldown(owner,{id:randomUUID(),source:'metrika_site',status:'error',mode:metrika!.mode,requestedAt:new Date().toISOString(),settingsRevision:expected,configId:metrika!.configId,requestKey:hash(['counter',counterId,expected,metrika!.configId]),context:{...analyticsDates(),timezone:'Europe/Moscow',attribution:'not_applicable',currency:'RUB',vat:'unknown',businessMeaning:'not_agreed'},query:{kind:'counter_metadata',counterId},attempts:1,error:error.message,cooldownUntil:error.retryAt,retryAt:error.retryAt});
      throw error;
    }
  }
  function disconnect(owner:string,expected:number){const current=db.readAnalyticsSettings(owner);return db.saveAnalyticsSettings(owner,{...current,metrikaEnabled:false,generation:current.generation+1},expected);}
  async function refresh(owner:string,source:AnalyticsSource){
    const s=db.readAnalyticsSettings(owner);validateDates(s.dateFrom,s.dateTo);
    const context:AnalyticsReport['context']={dateFrom:s.dateFrom,dateTo:s.dateTo,timezone:source==='direct_reports'?'unknown':'Europe/Moscow',attribution:source==='metrika_direct'?'last':'not_applicable',currency:'RUB',vat:source==='direct_reports'?'included':'unknown',businessMeaning:'not_agreed'};
    let c:ReturnType<typeof direct>|undefined;let query:any;let mode:'live'|'fixture';
    if(source==='direct_reports'||source==='metrika_direct'){c=direct(owner,s);const plan=db.readPlan(owner,c.run.campaignPlanId);Object.assign(context,{runId:c.run.planId,planId:c.run.campaignPlanId,planHash:plan?hash(plan):undefined,planTitle:plan?.draft.title,planConfirmedAt:plan?.confirmedAt,account:c.run.account,campaignId:c.campaignId});}
    if(source==='direct_reports'){mode=c!.connection.mode;query={campaignId:c!.campaignId,dateFrom:s.dateFrom,dateTo:s.dateTo,reportName:`E3_${randomUUID()}`};}
    else{
      if(!configured(owner)||!s.metrikaEnabled||!s.counter||!s.goalId)throw new DirectError('Прочитайте счётчик и выберите техническую цель; доступ должен быть включён.');
      if(s.metrikaConfigId!==metrika!.configId)throw new DirectError('Конфигурация доступа Метрики изменилась. Прочитайте счётчик и выберите цель заново.');
      const goal=s.counter.goals.find(g=>g.id===s.goalId);if(!goal)throw new DirectError('Цель не найдена в выбранном счётчике.');
      Object.assign(context,{counterId:s.counter.id,domain:s.counter.domain,goalId:goal.id,goalName:goal.name});mode=metrika!.mode;
      query={counterId:s.counter.id,goalId:goal.id,dateFrom:s.dateFrom,dateTo:s.dateTo};
      if(source==='metrika_direct'){if(!sameSite(c!.run.draft.url,s.counter)||!c!.connection.login)throw new DirectError('Сайт плана и счётчик или логин кабинета не соответствуют: общий CPA запрещён.');Object.assign(query,{campaignId:c!.campaignId,login:c!.connection.login});}
    }
    const cooldown=db.readAnalyticsCooldown(owner,source);if(cooldown)return cooldown;
    const key=hash([source,s.revision,context,c?.connection.generation,source==='direct_reports'?undefined:metrika!.configId]);
    let report=db.beginAnalyticsReport(owner,{id:randomUUID(),source,status:'pending',mode,requestedAt:new Date().toISOString(),settingsRevision:s.revision,connectionGeneration:c?.connection.generation,configId:source==='direct_reports'?undefined:metrika!.configId,requestKey:key,context,query,attempts:0});
    if(report.requestKey!==key)throw new DirectError('Предыдущее чтение относится к другой конфигурации. Сохраните настройки заново.');
    if(inFlight.has(report.id)||report.retryAt&&Date.now()<report.retryAt&&!report.interrupted)return report;
    const check=()=>{const actual=db.readAnalyticsSettings(owner);if(actual.revision!==s.revision||(source!=='direct_reports'&&(!actual.metrikaEnabled||metrika!.configId!==report.configId)))throw new DirectError('Чтение отключено или контекст изменился.');if(c){const current=resolveDirect(owner);if(!current||current.account!==c.connection.account||current.generation!==c.connection.generation)throw new DirectError('Подключение Директа изменилось.');}};
    const beforeSend=()=>{check();const wait=db.readAnalyticsCooldown(owner,source);if(wait)throw new ReadRateLimitError(source==='direct_reports'?'Reports':'Метрика',wait.cooldownUntil!);};
    inFlight.add(report.id);
    try{
      check();report={...report,attempts:report.attempts+1,pid:process.pid,retryAt:Date.now()+30000};db.updateAnalyticsReport(owner,report);
      const result=source==='direct_reports'?await c!.connection.api.reportRead(report.query,beforeSend):await metrika!.api.report(report.query as MetrikaQuery,beforeSend);
      check();report={...report,status:result.status,result,offlinePending:source==='direct_reports'&&result.status==='pending',error:undefined,cooldownUntil:undefined,receivedAt:result.status==='pending'?undefined:new Date().toISOString(),retryAt:result.status==='pending'?Date.now()+(result.retryIn??60)*1000:undefined};
    }catch(error){const actual=db.readAnalyticsSettings(owner),message=error instanceof DirectError?error.message:'Чтение недоступно. Повторите запрос; прежний результат сохранён.',retryAt=error instanceof ReadRateLimitError?error.retryAt:undefined;report={...report,status:actual.revision!==s.revision?'superseded':'error',cooldownUntil:retryAt,retryAt,error:message,failures:[...report.failures??[],{at:new Date().toISOString(),message,retryAt}]};if(error instanceof ReadRateLimitError)db.saveAnalyticsCooldown(owner,report.id,error.retryAt);}
    finally{inFlight.delete(report.id);}
    db.updateAnalyticsReport(owner,report);return report;
  }
  return{view,save,counter,disconnect,refresh};
}

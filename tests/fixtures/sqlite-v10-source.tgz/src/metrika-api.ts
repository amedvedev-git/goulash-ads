import { DirectError,ReadRateLimitError,retryAfterUntil } from './direct-api.ts';
import { createHash } from 'node:crypto';
export function metrikaConfigId(owner:string,version='1',provider:'dpapi'|'systemd'='dpapi'){
  if(!/^[\w.-]{1,80}$/.test(version))throw new DirectError('GOULASH_METRIKA_CONFIG_VERSION: нужна несекретная версия доступа до 80 букв, цифр, точек или дефисов.');
  return createHash('sha256').update(JSON.stringify([owner,provider,version])).digest('hex');
}
export type MetrikaCounter = {id:string;domain:string;mirrors:string[];goals:{id:string;name:string;type:string;condition:string}[]};
export type MetrikaQuery = {counterId:string;goalId:string;dateFrom:string;dateTo:string;campaignId?:string;login?:string};
export type MetrikaReport = {status:'ready'|'empty';metrics:{visits:number|null;reaches:number|null;goalVisits:number|null;cost:number|null;cpa:number|null};
  complete:boolean;issues:string[];dataLag:number;sampled:boolean;sampleShare:number|null;query:Record<string,unknown>};
const id=(value:unknown)=>{const s=String(value);if(!/^[1-9]\d{0,18}$/.test(s))throw new DirectError('Некорректный ID Метрики.');return s;};
export function metrikaParams(q:MetrikaQuery){
  const ad=Boolean(q.campaignId),g=id(q.goalId);
  const metrics=ad?[`ym:ad:RUBConvertedAdCost`,`ym:ad:goal${g}reaches`,`ym:ad:goal${g}visits`,`ym:ad:goal${g}convertedRUBCPA`]:['ym:s:visits',`ym:s:goal${g}reaches`,`ym:s:goal${g}visits`];
  const params=new URLSearchParams({ids:id(q.counterId),metrics:metrics.join(','),date1:q.dateFrom,date2:q.dateTo,timezone:'+03:00',accuracy:'full',attribution:'last',currency:'RUB',limit:'10'});
  if(ad){if(!q.login||!/^[\w.@-]{1,100}$/.test(q.login))throw new DirectError('Логин кабинета не подтверждён.');params.set('dimensions','ym:ad:lastDirectOrder');params.set('filters',`ym:ad:lastDirectOrder==${id(q.campaignId)}`);params.set('direct_client_logins',q.login);}
  return params;
}
export function parseMetrikaReport(data:any,q:MetrikaQuery,now=Date.now()):MetrikaReport{
  const p=metrikaParams(q),expected=p.get('metrics')!.split(','),ad=Boolean(q.campaignId),query=data?.query;
  if(!query||JSON.stringify(query.metrics)!==JSON.stringify(expected)||query.date1!==q.dateFrom||query.date2!==q.dateTo||query.timezone!=='+03:00'||(ad&&(query.filters!==p.get('filters')||JSON.stringify(query.dimensions)!==JSON.stringify(['ym:ad:lastDirectOrder'])))||!Array.isArray(data.data)||!Array.isArray(data.totals)||data.totals.length!==expected.length||!Number.isSafeInteger(data.total_rows)||data.total_rows<0||typeof data.sampled!=='boolean'||!Number.isSafeInteger(data.data_lag)||data.data_lag<0)throw new DirectError('Метрика: ответ не соответствует запросу.');
  const number=(v:unknown)=>{if(v===null||v===undefined)return null;if(typeof v!=='number'||!Number.isFinite(v)||v<0)throw new DirectError('Метрика: некорректный показатель.');return v;};
  const issues:string[]=[];
  if(!ad&&((query.dimensions?.length??0)>0||query.filters))throw new DirectError('Метрика: отчёт всего сайта неожиданно ограничен сегментом.');
  if(data.sampled||data.sample_share!==1)issues.push('Семплированный отчёт');
  if(data.total_rows_rounded||data.total_rows>data.data.length||data.contains_sensitive_data)issues.push('Неполная выборка');
  if(now-data.data_lag*1000<Date.parse(q.dateTo)+86400000-10800000)issues.push('Данные периода ещё обновляются');
  if(data.data.length>1)throw new DirectError('Метрика: неожиданный объём выборки.');
  const row=data.data[0];if(row&&(!Array.isArray(row.metrics)||row.metrics.length!==expected.length))throw new DirectError('Метрика: неполная строка.');
  if(ad&&row&&String(row.dimensions?.[0]?.id)!==q.campaignId)throw new DirectError('Метрика: кампания не соответствует запросу.');
  const values=(row?.metrics??data.totals).map(number);
  const metrics=ad?{visits:null,reaches:values[1],goalVisits:values[2],cost:values[0],cpa:values[3]}:{visits:values[0],reaches:values[1],goalVisits:values[2],cost:null,cpa:null};
  if(values.some((v:unknown)=>v===null))issues.push('Нет части показателей');
  return {status:!data.data.length&&data.total_rows===0?'empty':'ready',metrics,complete:issues.length===0,issues,dataLag:data.data_lag,sampled:data.sampled,sampleShare:number(data.sample_share),query};
}
export function createMetrikaApi(token:()=>Promise<string>,transport:typeof fetch=fetch){
  async function get(path:string,params:URLSearchParams,beforeSend?:()=>void){
    let response:Response;try{const secret=await token();beforeSend?.();response=await transport(`https://api-metrika.yandex.net${path}?${params}`,{headers:{Authorization:`OAuth ${secret}`},redirect:'error',signal:AbortSignal.timeout(20000)});}catch(error){if(error instanceof ReadRateLimitError)throw error;throw new DirectError('Метрика: доступ отключён или соединение недоступно. Повторите чтение.');}
    if(response.status===429)throw new ReadRateLimitError('Метрика',retryAfterUntil(response.headers.get('Retry-After')));
    if(!response.ok)throw new DirectError(`Метрика: HTTP ${response.status}. ${response.status===401||response.status===403?'Проверьте доступ к счётчику.':'Чтение не завершено.'}`);
    const text=await response.text();if(Buffer.byteLength(text)>2097152)throw new DirectError('Метрика: ответ слишком большой.');
    try{return JSON.parse(text);}catch{throw new DirectError('Метрика: некорректный JSON.');}
  }
  return {async counter(counterId:string,beforeSend?:()=>void):Promise<MetrikaCounter>{
    const d=(await get(`/management/v1/counter/${id(counterId)}`,new URLSearchParams({field:'goals,mirrors'}),beforeSend)).counter;
    if(!d||String(d.id)!==counterId||typeof d.site!=='string'&&typeof d.domain!=='string'||!Array.isArray(d.goals))throw new DirectError('Метрика: карточка счётчика неполна.');
    return {id:counterId,domain:d.site??d.domain,mirrors:Array.isArray(d.mirrors)?d.mirrors.filter((v:unknown)=>typeof v==='string'):[],goals:d.goals.filter((g:any)=>!g.is_deleted).map((g:any)=>({id:id(g.id),name:String(g.name).slice(0,200),type:String(g.type),condition:(g.conditions??[]).map((c:any)=>String(c.url??c.type??'')).join(', ').slice(0,500)}))};
  },async report(q:MetrikaQuery,beforeSend?:()=>void){return parseMetrikaReport(await get('/stat/v1/data',metrikaParams(q),beforeSend),q);}};
}
export type MetrikaApi=ReturnType<typeof createMetrikaApi>;
export type MetrikaProvider={owner:string;mode:'live'|'fixture';configId:string;api:MetrikaApi};
